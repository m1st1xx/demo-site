#!/bin/bash
hostnamectl set-hostname isp
cat << 'EOF' > /etc/network/interfaces
auto ens33
iface ens33 inet dhcp

auto ens37
iface ens37 inet static
address 172.16.1.1
netmask 255.255.255.224

auto ens38
iface ens38 inet static
address 172.16.2.1
netmask 255.255.255.224
EOF

iptables -t nat -A POSTROUTING -o ens33 -j MASQUERADE
netfilter-persistent save
touch /etc/sysctl.d/sysctl.conf
echo "net.ipv4.ip_forward = 1" > /etc/sysctl.d/sysctl.conf
touch /etc/sysctl.conf
echo "net.ipv4.ip_forward = 1" > /etc/sysctl.conf
sysctl -p
timedatectl set-timezone Europe/Moscow
