#!/bin/bash
hostnamectl set-hostname br-fw.au-team.irpo
cat << 'EOF' > /etc/network/interfaces
auto ens33
iface ens33 inet static
address 192.168.40.2
netmask 255.255.255.252
gateway 192.168.40.1
auto ens37
iface ens37 inet static
address 192.168.50.1
netmask 255.255.255.0
EOF
echo "nameserver 192.168.100.2" >> /etc/resolv.conf

iptables -t nat -A POSTROUTING -o ens33 -j MASQUERADE
netfilter-persistent save
touch /etc/sysctl.d/sysctl.conf
echo "net.ipv4.ip_forward = 1" > /etc/sysctl.d/sysctl.conf
touch /etc/sysctl.conf
echo "net.ipv4.ip_forward = 1" > /etc/sysctl.conf
sysctl -p
systemctl restart networking

sed -i 's/^ospfd=no/ospfd=yes/' /etc/frr/daemons
sudo vtysh <<EOF
conf t
router ospf
network 192.168.40.0/30 area 0
network 192.168.50.0/24 area 0
end
wr memory
EOF
systemctl restart frr
systemctl enable frr
timedatectl set-timezone Europe/Moscow

