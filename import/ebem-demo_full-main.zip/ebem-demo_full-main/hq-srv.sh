#!/bin/bash
hostnamectl set-hostname hq-srv.au-team.irpo
echo "nameserver 192.168.100.2" >> /etc/resolv.conf
echo "8021q" >> /etc/modules
modprobe 8021q
cat << 'EOF' > /etc/network/interfaces
auto ens33.100
iface ens33.100 inet static
address 192.168.100.2
netmask 255.255.255.224
gateway 192.168.100.1
vlan-raw-device ens33
EOF
systemctl restart networking
useradd -m -u 2027 -s /bin/bash sshuser
echo "sshuser:12345678" | chpasswd
echo "sshuser ALL=(ALL) NOPASSWD: ALL" > /etc/sudoers.d/sshuser
chmod 440 /etc/sudoers.d/sshuser
visudo -c

echo "PermitRootLogin no
PasswordAuthentication yes
Port 2027" >> /etc/ssh/sshd_config
echo "AllowUsers sshuser
MaxAuthTries 2
Banner /etc/ssh/banner" >> /etc/ssh/sshd_config
touch /etc/ssh/banner
cat << "EOF" > /etc/ssh/banner
########################
#AUTHORIZED ACCESS ONLY#
########################
EOF
systemctl restart ssh
systemctl restart sshd

apt install -y bind9 bind9-utils
cat << "EOF" > /etc/bind/named.conf.local
zone "au-team.irpo" {
	type master;
	file "/etc/bind/zones/db.au-team.irpo";
	allow-transfer {none; };
	allow-update {none; };
};

zone "100.168.192.in-addr.arpa" {
	type master;
	file "/etc/bind/zones/db.100.168.192";
	allow-transfer {none; };
	allow-update {none; };
};

zone "200.168.192.in-addr.arpa" {
	type master;
	file "/etc/bind/zones/db.200.168.192";
	allow-transfer {none; };
	allow-update {none; };
};

zone "50.168.192.in-addr.arpa" {
	type master;
	file "/etc/bind/zones/db.50.168.192";
	allow-transfer {none; };
	allow-update {none; };
};
EOF
cat << "EOF" > /etc/bind/named.conf.options
options {
	directory "/var/cache/bind";

	allow-query {any; };
		forwarders {
			8.8.8.8;
			1.1.1.1;
		};
	listen-on-v6 {any; };
	allow-update {192.168.50.2;};
};
EOF
mkdir -p /etc/bind/zones
touch /etc/bind/zones/db.au-team.irpo
cat << "EOF" > /etc/bind/zones/db.au-team.irpo
$TTL 86400
@   IN  SOA     au-team.irpo. root.au-team.irpo. (
        2             ; Serial 
        604800        ; Refresh 
       2419200        ; Retry 
        604800        ; Expire 
        604800 )      ; Minimum TTL 

; 
@   IN  NS      au-team.irpo.
@   IN  A      192.168.100.2

hq-rtr.au-team.irpo. IN  A       172.16.1.2
br-rtr.au-team.irpo. IN  A       172.16.2.2
hq-srv.au-team.irpo. IN  A       192.168.100.2
br-srv.au-team.irpo. IN  A       192.168.50.2
hq-cli.au-team.irpo. IN  A       192.168.200.2
br-fw.au-team.irpo. IN  A       192.168.40.2
docker.au-team.irpo. IN  A       172.16.1.1
web.au-team.irpo. IN  A       172.16.2.1
EOF
touch /etc/bind/zones/db.100.168.192
cat << "EOF" > /etc/bind/zones/db.100.168.192
$TTL 86400
@   IN  SOA     192.168.100.in-addr.arpa. root.192.168.100.in-addr.arpa. (
        2             ; Serial 
        604800        ; Refresh 
       2419200        ; Retry 
        604800        ; Expire 
        604800 )      ; Minimum TTL 

; 
@   IN  NS      hq-srv.au-team.irpo.

1 IN  PTR       hq-rtr.au-team.irpo.
2 IN  PTR       hq-srv.au-team.irpo.
3 IN  PTR       hq-cli.au-team.irpo.
EOF
touch /etc/bind/zones/db.50.168.192
cat << "EOF" > /etc/bind/zones/db.50.168.192
$TTL 86400
@   IN  SOA     192.168.50.in-addr.arpa. root.192.168.50.in-addr.arpa. (
        2             ; Serial 
        604800        ; Refresh 
       2419200        ; Retry 
        604800        ; Expire 
        604800 )      ; Minimum TTL 

; 
@   IN  NS      hq-srv.au-team.irpo.

1 IN  PTR       br-rtr.au-team.irpo.
2 IN  PTR       br-srv.au-team.irpo.
3 IN  PTR       br-fw.au-team.irpo.
EOF
touch /etc/bind/zones/db.200.168.192
cat << "EOF" > /etc/bind/zones/db.200.168.192
$TTL 86400
@   IN  SOA     192.168.200.in-addr.arpa. root.192.168.200.in-addr.arpa. (
        2             ; Serial 
        604800        ; Refresh 
       2419200        ; Retry 
        604800        ; Expire 
        604800 )      ; Minimum TTL 

; 
@   IN  NS      hq-srv.au-team.irpo.

1 IN  PTR       hq-rtr.au-team.irpo.
2 IN  PTR       hq-srv.au-team.irpo.
3 IN  PTR       hq-cli.au-team.irpo.
EOF
systemctl start bind9
systemctl restart bind9
timedatectl set-timezone Europe/Moscow
