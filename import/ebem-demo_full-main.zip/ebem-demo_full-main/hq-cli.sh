#!/bin/bash
hostnamectl set-hostname hq-cli.au-team.irpo
echo "8021q" >> /etc/modules
modprobe 8021q
cat << 'EOF' > /etc/network/interfaces
auto ens33.200
iface ens33.200 inet dhcp
EOF
systemctl restart networking
timedatectl set-timezone Europe/Moscow
