#!/bin/bash
hostnamectl set-hostname hq-rtr.au-team.irpo
echo "8021q" >> /etc/modules
echo "ip_gre" >> /etc/modules
modprobe 8021q
modprobe ip_gre
cat << 'EOF' > /etc/network/interfaces
auto ens33
iface ens33 inet static
address 172.16.1.2
netmask 255.255.255.224
gateway 172.16.1.1
auto ens37.100
iface ens37.100 inet static
address 192.168.100.1
netmask 255.255.255.224
vlan-raw-device ens37
auto ens37.200
iface ens37.200 inet static
address 192.168.200.1
netmask 255.255.255.240
vlan-raw-device ens37
auto ens37.999
iface ens37.999 inet static
address 192.168.99.1
netmask 255.255.255.248
vlan-raw-device ens37
auto gre30
iface gre30 inet tunnel
address 10.10.10.1
netmask 255.255.255.252
mode gre
local 172.16.1.2
endpoint 172.16.2.2
ttl 255
EOF
echo "nameserver 192.168.100.2" >> /etc/resolv.conf
iptables -t nat -A POSTROUTING -o ens33 -j MASQUERADE
netfilter-persistent save
touch /etc/sysctl.d/sysctl.conf
echo "net.ipv4.ip_forward = 1" > /etc/sysctl.d/sysctl.conf
touch /etc/sysctl.conf
echo "net.ipv4.ip_forward = 1" > /etc/sysctl.conf
sysctl -p
systemctl restart networking

useradd -m -u 2027 -s /bin/bash net_admin
echo "net_admin:12345678" | chpasswd
echo "net_admin ALL=(ALL) NOPASSWD: ALL" > /etc/sudoers.d/net_admin
chmod 440 /etc/sudoers.d/net_admin
visudo -c

sed -i 's/^ospfd=no/ospfd=yes/' /etc/frr/daemons
sudo vtysh <<EOF
conf t
interface gre30
ip ospf authentication message-digest
ip ospf message-digest-key 1 md5 admin
ip ospf network broadcast
no ip ospf passive
router ospf
network 10.10.10.0/30 area 0
network 192.168.100.0/27 area 0
network 192.168.200.0/28 area 0
network 192.168.99.0/29 area 0
end
wr memory
EOF
systemctl restart frr
systemctl enable frr
apt install -y isc-dhcp-server
cat << "EOF" > /etc/dhcp/dhcpd.conf
option domain-name "au-team.irpo";
option domain-name-servers 192.168.100.2;
default-lease-time 600;
max-lease-time 7200;
ddns-update-style none;
subnet 192.168.200.0 netmask 255.255.255.240 {
range 192.168.200.2 192.168.200.14;
option routers 192.168.200.1;
option subnet-mask 255.255.255.240;
option broadcast-address 192.168.200.15;
option domain-name-servers 192.168.100.2;
default-lease-time 600;
max-lease-time 7200;
}
EOF
cat << "EOF" > /etc/default/isc-dhcp-server
DHCPDv4_CONF=/etc/dhcp/dhcpd.conf
DHCPDv4_PID=/var/run/dhcpd.pid
INTERFACESv4="ens37.200"
EOF
systemctl restart isc-dhcp-server
systemctl enable isc-dhcp-server
timedatectl set-timezone Europe/Moscow
