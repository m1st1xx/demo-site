#!/bin/bash
hostnamectl set-hostname br-rtr.au-team.irpo
echo "ip_gre" >> /etc/modules
modprobe ip_gre
cat << 'EOF' > /etc/network/interfaces
auto ens33
iface ens33 inet static
address 172.16.2.2
netmask 255.255.255.224
gateway 172.16.2.1
auto ens37
iface ens37 inet static
address 192.168.40.1
netmask 255.255.255.252
auto gre30
iface gre30 inet tunneld
address 10.10.10.2
netmask 255.255.255.252
mode gre
local 172.16.2.2
endpoint 172.16.1.2
ttl 255
EOF
echo "nameserver 192.168.100.2" >> /etc/resolv.conf
iptables -t nat -A POSTROUTING -o ens33 -j MASQUERADE
netfilter-persistent save
touch /etc/sysctl.d/sysctl.conf
echo "net.ipv4.ip_forward = 1" > /etc/sysctl.d/sysctl.conf
touch /etc/sysctl.conf
echo "net.ipv4.ip_forward = 1" > /etc/sysctl.conf
sysctl -p
systemctl restart networking

useradd -m -u 2027 -s /bin/bash net_admin
echo "net_admin:12345678" | chpasswd
echo "net_admin ALL=(ALL) NOPASSWD: ALL" > /etc/sudoers.d/net_admin
chmod 440 /etc/sudoers.d/net_admin
visudo -c

sed -i 's/^ospfd=no/ospfd=yes/' /etc/frr/daemons
sudo vtysh <<EOF
conf t
interface gre30
ip ospf authentication message-digest
ip ospf message-digest-key 1 md5 admin
ip ospf network broadcast
no ip ospf passive
router ospf
network 10.10.10.0/30 area 0
network 192.168.40.0/30 area 0
end
wr memory
EOF
systemctl restart frr
systemctl enable frr

timedatectl set-timezone Europe/Moscow


